# Oito conectores: identidade documental para revisão de catálogo

Entregável V02 preparado em **01/10/2026**, com produtos reais e fontes públicas da Phoenix Contact. Curadoria realizada por IA; sem revisão humana independente, encomenda de cliente ou aceite comercial.

Abra [o CSV](connector-identity-sample.csv) em Excel/Sheets, importando códigos e GTIN como **texto**. O [JSON](connector-identity-sample.json) contém os mesmos registros, cinco decisões de curadoria e os localizadores de evidência. O número de artigo e a designação original foram preservados. Campo vazio/null significa não determinado.

| Código original | Distinção documentada | Embalagem observada |
|---|---|---:|
| 1757019 | MSTB, 2 posições, verde | 100 peças |
| 1757022 | MSTB, 3 posições, verde | 100 peças |
| 1757035 | MSTB, 4 posições, verde | 100 peças |
| 1778001 | MSTB STF, 4 posições, flange de parafuso | 100 peças |
| 1757048 | MSTB, 5 posições, verde | 100 peças |
| 1758843 | MSTB BK, 4 posições, preto | 50 peças |
| 1731879 | MSTBC BK, 4 posições, crimpagem | 50 peças |
| 1863712 | SMSTB BK, 4 posições, entrada a −45°; PDF reconsultado | 50 peças |

Todos registram passo de 5,08 mm. Isso não autoriza agrupar suas identidades: preservar número de posições, ST/STF, BK, MSTB/MSTBC/SMSTB, método de conexão e embalagem. Clip e mecanismo de travamento são campos separados. A documentação consultada está ligada em **source_url**, com seção/página em **source_locator**, por linha.

**Abstenções que acompanham a entrega:** na primeira consulta, o PDF de 1863712 retornou data de 02/09/2025; na reconferência do Codex, retornou Oct 2, 2026, 12:22AM. Os campos principais foram reconferidos. A mudança de data impressa não demonstra revisão técnica; o HTML falhou na consulta inicial e a vigência comercial brasileira continua não determinada. Para 1731879, não foi determinada a composição exata dos contatos fornecidos. Quantidades comerciais pertencem às fontes en-us consultadas e não confirmam estoque, preço ou oferta no Brasil. As datas impressas de PDFs não são tratadas como datas de revisão técnica.

Esta amostra demonstra o formato de uma entrega de curadoria: oito identidades separadas, variantes preservadas, referências e pendências. Não houve catálogo de cliente, erros de cliente descobertos, importação, economia de tempo medida ou recomendação de compatibilidade/substituição. Nenhum catálogo integral ou imagem upstream foi redistribuído. CSV e JSON tiveram leitura estrutural conferida; isso não equivale a auditoria humana ou teste de componentes.
