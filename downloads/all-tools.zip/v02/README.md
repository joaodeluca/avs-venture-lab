# Catálogo — avaliação documental local

Ferramenta gratuita para comparar fatos de conectores já estruturados. Não verifica URLs, não determina substituição e não altera ERP. Somente Python3/biblioteca padrão.

`python3 catalog_delivery.py entrada.json --out-dir minha-revisao`

A entrada segue o esquema de catalog_engine.py (schema_version, sources, pairs). Cada fato tem value e source_id. O pitch exige unit mm/cm/in. O utilitário escreve report.json, divergences.csv e report.html, sem rede. Observado na entrada é classificação declarada pelo operador, não autenticada pelo motor.

A amostra documental de oito produtos reais tem fontes e desconhecidos, mas não é catálogo de cliente ou entrega aceita. CSV mantém códigos como texto: importe explicitamente strings em planilhas. Qualquer CSV novo do relatório neutraliza fórmulas em texto; JSON preserva valor original. Não use as saídas para homologar componentes.

Use dados próprios apenas localmente; não publique exports privados, credenciais ou dados pessoais em issues. Uma entrega feita sob encomenda exige escopo e revisão separados.
