#!/usr/bin/env python3
"""Render a local structured comparison; supplied source facts are not authenticated."""
import argparse
import csv
import html
import json
from pathlib import Path
from catalog_engine import run


def csv_text(value):
    value = str(value)
    return "'" + value if value.lstrip().startswith(('=', '+', '-', '@')) else value


def deliver(source, output):
    with Path(source).open("rb") as stream:
        raw = stream.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError('Input exceeds 2 MB')
    result = run(json.loads(raw))
    result['source_verification'] = 'supplied_by_operator_not_authenticated'
    result['customer_delivery_accepted'] = False
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    paths = [output / x for x in ('report.json', 'divergences.csv', 'report.html')]
    if any(x.exists() for x in paths):
        raise ValueError('Output files already exist; choose a new directory')
    paths[0].write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    with paths[1].open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['pair_id', 'status', 'issue', 'field', 'side'])
        for row in result['results']:
            for issue in row['issues']:
                w.writerow([csv_text(v) for v in (row['id'], row['status'], issue['code'], issue.get('field', ''), issue.get('side', ''))])
    esc = html.escape
    rows = ''.join('<tr><td>' + esc(row['id']) + '</td><td>' + esc(row['status']) + '</td><td>' + str(len(row['issues'])) + '</td></tr>' for row in result['results'])
    paths[2].write_text('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Revisão de catálogo</title><style>body{max-width:1000px;margin:40px auto;padding:20px;font:16px system-ui}td,th{padding:12px;text-align:left;border-bottom:1px solid #ddd}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style><h1>Revisão de catálogo</h1><p>Fontes fornecidas pelo operador, sem autenticação. Nenhuma substituição ou fusão aprovada. Não é entrega aceita pelo cliente.</p><table><tr><th>Par</th><th>Estado</th><th>Pendências</th></tr>' + rows + '</table><h2>Relatório completo</h2><pre>' + esc(json.dumps(result, ensure_ascii=False, indent=2)) + '</pre></html>')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input', type=Path)
    p.add_argument('--out-dir', required=True, type=Path)
    a = p.parse_args()
    try:
        deliver(a.input, a.out_dir)
    except (OSError, ValueError, TypeError, RecursionError) as exc:
        p.exit(2, f'Entrada recusada: {exc}\n')
