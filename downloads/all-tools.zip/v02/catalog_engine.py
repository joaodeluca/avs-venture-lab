#!/usr/bin/env python3
"""V02: finite, offline comparison of already structured connector facts."""
import argparse
from collections import Counter
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import sys

VERSION = "0.1.0"
FIELDS = ("manufacturer", "mpn", "positions", "pitch", "contact", "termination", "variant", "sales_unit", "pack_qty")
TECHNICAL = {"positions", "pitch", "contact", "termination", "variant"}
ENUMS = {"contact": {"socket", "pin"}, "sales_unit": {"piece", "pack"}}
UNITS = {"mm": Decimal("1"), "cm": Decimal("10"), "in": Decimal("25.4")}


def normalized(field, fact):
    """No fuzzy MPN matching, synonym inference, expressions, code or network."""
    value = fact.get("value")
    if field in {"positions", "pack_qty"}:
        if type(value) is not int or not 0 < value <= 1000000:
            raise ValueError("expected positive integer <= 1000000")
        return value
    if field == "pitch":
        if type(value) not in (str, int, float) or len(str(value)) > 40 or not re.fullmatch(r"[0-9]+(?:[.,][0-9]+)?", str(value)):
            raise ValueError("invalid decimal")
        if fact.get("unit") not in UNITS:
            raise ValueError("unknown dimension/unit")
        try:
            number = Decimal(str(value).replace(",", "."))
        except InvalidOperation as exc:
            raise ValueError("invalid decimal") from exc
        if not number.is_finite() or not Decimal("0") < number <= Decimal("10000"):
            raise ValueError("invalid pitch range")
        return number * UNITS[fact["unit"]]
    if not isinstance(value, str) or not value.strip() or len(value) > 200:
        raise ValueError("expected nonempty text <= 200 characters")
    # Only trim MPN: punctuation, case, suffix and leading zeros remain significant.
    result = value.strip() if field == "mpn" else " ".join(value.casefold().split())
    if field in ENUMS and result not in ENUMS[field]:
        raise ValueError("unknown controlled value")
    return result


def validate_document(document):
    if not isinstance(document, dict) or set(document) != {"schema_version", "sources", "pairs"}:
        raise ValueError("expected schema_version, sources, pairs only")
    if document["schema_version"] != 1:
        raise ValueError("unsupported schema")
    sources, pairs = document["sources"], document["pairs"]
    if not isinstance(sources, dict) or not isinstance(pairs, list) or not 1 <= len(pairs) <= 1000:
        raise ValueError("expected sources object and 1..1000 pairs")
    for key, source in sources.items():
        if not isinstance(source, dict) or source.get("kind") not in {"synthetic", "observed"}:
            raise ValueError("invalid source")
        for attr in ("locator", "accessed_on", "label"):
            if not isinstance(source.get(attr), str) or not source[attr].strip():
                raise ValueError("source needs locator, accessed_on and label")
    ids = set()
    for pair in pairs:
        if not isinstance(pair, dict) or set(pair) - {"id", "evidence_kind", "left", "right", "expected_status", "note"}:
            raise ValueError("invalid pair shape")
        if not isinstance(pair.get("id"), str) or pair["id"] in ids:
            raise ValueError("pair IDs must be unique strings")
        ids.add(pair["id"])
        if pair.get("evidence_kind") not in {"synthetic", "observed"}:
            raise ValueError("invalid evidence kind")
        for side in ("left", "right"):
            record = pair.get(side)
            if not isinstance(record, dict) or set(record) - set(FIELDS):
                raise ValueError("unknown field or invalid record")
            for fact in record.values():
                if not isinstance(fact, dict) or set(fact) - {"value", "unit", "source_id"}:
                    raise ValueError("invalid fact shape")
                source_id = fact.get("source_id")
                if source_id is not None and not isinstance(source_id, str):
                    raise ValueError("source_id must be a string")
                source = sources.get(source_id)
                if source and source["kind"] != pair["evidence_kind"]:
                    raise ValueError("evidence kind does not match source")


def compare_pair(pair, sources):
    values = {"left": {}, "right": {}}
    issues, comparisons = [], []
    for field in FIELDS:
        for side in ("left", "right"):
            fact = pair[side].get(field)
            if fact is None:
                issues.append({"code": "missing_fact", "field": field, "side": side})
                continue
            source_id = fact.get("source_id")
            if source_id not in sources:
                issues.append({"code": "missing_source", "field": field, "side": side})
                continue
            try:
                values[side][field] = normalized(field, fact)
            except ValueError as exc:
                issues.append({"code": "invalid_fact", "field": field, "side": side, "reason": str(exc), "source_id": source_id})
        if field in values["left"] and field in values["right"]:
            left, right = values["left"][field], values["right"][field]
            comparisons.append({"field": field, "equal": left == right,
                                "left": str(left), "right": str(right),
                                "normalized_unit": "mm" if field == "pitch" else None,
                                "source_ids": [pair[side][field]["source_id"] for side in ("left", "right")]})
    compared = {row["field"]: row for row in comparisons}
    identity_known = all(field in compared for field in ("manufacturer", "mpn"))
    same_identifier = identity_known and all(compared[field]["equal"] for field in ("manufacturer", "mpn"))
    identity = "same_identifier" if same_identifier else "different_identifiers" if identity_known else "ambiguous_identity"
    for row in comparisons:
        if not row["equal"]:
            field = row["field"]
            code = "explicit_technical_mismatch" if field in TECHNICAL else "commercial_mismatch" if field in {"sales_unit", "pack_qty"} else "identifier_mismatch"
            issues.append({"code": code, "field": field, "source_ids": row["source_ids"]})
    codes = {issue["code"] for issue in issues}
    if "explicit_technical_mismatch" in codes:
        status = "conflicting_data" if same_identifier else "explicit_mismatch"
    elif "commercial_mismatch" in codes:
        status = "commercial_mismatch"
    elif not identity_known:
        status = "ambiguous_identity"
    elif identity != "same_identifier":
        status = "different_identity_review"
    elif issues:
        status = "insufficient_information"
    else:
        status = "aligned_record_fields"
    return {"id": pair["id"], "evidence_kind": pair["evidence_kind"], "identity": identity,
            "status": status, "comparisons": comparisons, "issues": issues,
            "auto_merge": False, "substitution_approved": False, "application_suitability": "not_evaluated"}


def run(document):
    validate_document(document)
    results = [compare_pair(pair, document["sources"]) for pair in document["pairs"]]
    canonical = json.dumps(document, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    return {"engine_version": VERSION, "input_sha256": hashlib.sha256(canonical).hexdigest(),
            "scope": "structured_connector_catalog_reconciliation_only", "sources": document["sources"],
            "evidence_counts": dict(sorted(Counter(row["evidence_kind"] for row in results).items())),
            "status_counts": dict(sorted(Counter(row["status"] for row in results).items())), "results": results,
            "commercial_validation": "not_demonstrated", "advantage_over_internal_ai": "not_demonstrated"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="local JSON, maximum 2 MB")
    parser.add_argument("--output", type=Path, help="local JSON report; otherwise stdout")
    args = parser.parse_args()
    try:
        with args.input.open("rb") as stream:
            raw = stream.read(2000001)
        if len(raw) > 2000000:
            raise ValueError("input exceeds 2 MB")
        document = json.loads(raw)
        output = json.dumps(run(document), indent=2, ensure_ascii=False, allow_nan=False) + "\n"
        if args.output:
            args.output.write_text(output, encoding="utf-8")
        else:
            print(output, end="")
    except (ValueError, OSError, RecursionError) as exc:
        print(f"Invalid input: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
