# ExitForge — recorte local independente

Gratuito. Somente Python3 e biblioteca padrão. Este pacote não requer n8n, conta, token ou chave.

`python3 aggregate.py examples/input.json`

Entrada offline: traffic e revenue são snapshots com status HTTP e json objeto. Conteúdo é declarado pelo usuário, não consultado/autenticado. Arrays/nulos são recusados; timeout produz UNKNOWN, sem saída parcial. O nome revenue/daily-kpi é herança do exemplo, não valida resultado financeiro.

`python3 verify_example.py` confere casos construídos. `python3 -m unittest test_http_adapter.py` confere o adaptador HTTP com servidor local sintético. Esses checks não provam equivalência com n8n/transpiler ou migração de cliente.

Leitura HTTP opcional: `python3 live_demo.py https://api.github.com/repos/c4snipes/n8n-transpiler https://api.github.com/repos/n8n-io/n8n`. Dois GETs públicos explícitos; isso faz chamadas de rede. Os endpoints originais fictícios foram substituídos. Não executa escrita, OAuth, scheduler, dashboard ou estado durável.

Atribuição e diferenças em provenance.json e THIRD_PARTY_NOTICE.md. Código original; nenhum fonte upstream integral incluído. O pacote não converte exports arbitrários e não constitui serviço contratado. Não publique seus exports privados em issues.
