# v01 — poc: pacote local revisado

Descompacte antes de executar. `site/` contém a interface e seus assets locais. Para abrir módulos e usar SHA256, use um navegador moderno e servidor local (não file://):

```sh
cd site
python3 -m http.server 8773 --bind 127.0.0.1
```

Abra http://127.0.0.1:8773/tools/poc/workspace.html. O servidor é estático e não recebe upload; não adicione arquivos privados à pasta servida. O servidor local pode registrar seus GETs no terminal. Módulos/BigInt/Web Crypto precisam de suporte do navegador; SHA256 pode exigir HTTPS ou localhost. O toolkit não faz analytics nem envia os textos das suas entradas. A ferramenta selecionada funciona com assets locais; navegação às outras ferramentas e novos ZIPs abre o portal público e precisa de rede.

`python/` contém os pacotes Python correspondentes, com README, exemplos e limites próprios. Execute comandos dentro da pasta específica. O V05 inclui a extração pequena revisada do pacote original; não é um conversor universal. Seus GETs públicos opcionais são explícitos e precisam de rede. O V04 é produtor determinístico + verificador local de FAQ fictícia, não um LLM/oráculo.

Todos os exemplos são fictícios ou fatos/referências selecionados que os seus READMEs identificam. Status, declarações, hash, matching local e demonstração não são execução autenticada de cliente, homologação, venda ou aceite externo. Não publique dados privados. Não há checkout, contratação ou cobrança habilitados.

Os arquivos HTML de pacote conservam funcionalidades locais; links de navegação/ZIP fora deste pacote foram apontados ao portal canônico apenas nesta cópia. Nenhum código de engine foi alterado pelo empacotamento. Leia as atribuições e exclusões dos pacotes antes de usar.
