# Verificador local do pacote de fechamento

Extraia este ZIP antes de executar. Conferido com Node 24.15.0; sem dependências de terceiros.

node verify-intake-package.mjs /caminho/fechamento-pacote-local.json

Imprime JSON recalculado em stdout. Não envia dados, não grava arquivos, não executa HTML ou comandos contidos no pacote. Confira os originais e os limites antes de compartilhar o pacote, que pode conter dados privados.

Confere os três originais base64/SHA256, UTF-8, mapeamentos e auditoria; compara normalizados e recalcula contrato linear/eventos/fatura. Ignora report/report_html arquivados. CSV até2MB cada, envelope até12MB, até31dias/10000eventos/100medidores/100linhas. Completude continua declarada; unknown/incomplete impede comparação monetária.

Hash não autentica fonte nem completude. Envelope usa JSON.parse padrão: chaves duplicadas não são detectadas e prevalece a última. Pacote reconstruído consistentemente pode passar; não é prova contra um autor malicioso. Metadados, origem e completude não são verificados externamente. Não certifica contabilidade, aceite, recuperação de receita ou autorização de cobrança.

Testes sintéticos novos: node --test test-intake.mjs test-intake-integration.mjs test-verify-intake-package.mjs

Workspace: https://joaodeluca.github.io/avs-venture-lab/tools/revenue/intake.html
Código original e dependências locais: https://github.com/joaodeluca/avs-venture-lab/tree/main/tools/revenue
